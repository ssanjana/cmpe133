class AboutController < ApplicationController
  def index
    @page_title = 'About Us'
  end

end
